% Kernel learning via semi-definite programming (SDP) in multi-class case
% Coded by Jianhui Chen (jianhui.chen@asu.edu, Arizona State University)

%                Input Parameters
% "G" : the cell containing centered kernel matrix (trace value = 1) 
% "lambda" : regularization parameter
% "H" : the indicator matrix

%               Output parameters
% "theta" : the coefficients of kernel matrices
% "time" : computation time in seconds

function [theta time] = Multi_SDP_Theta(G, H, lambda)

time0 = cputime;

len = length(G);
[ n k ] = size(H);

At = [];
C = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% 1: Set equality constraint(\theta^T * r = 1), K.f = 1;%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

C = [C;1];
At = [ At ; [zeros(1,k) ones(1,len) ] ];
K.f = 1; % # of free variables

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2: Set nonnegative constraint(\theta \ge 0), K.l = sigma_length;    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tmp = [ ];
tmp = [ zeros(len,k) eye(len) ];
At = [At ; -tmp];
C = [C ; zeros(len,1)];
K.l = len; % # of non-negative variables

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3. Set cone constraints as indicated in Eq.(93), K.s = sigma_length;    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
F_C = [eye(n), H; H',zeros(k,k)];
C = [C;vec(F_C)];
    
a_cone = [];
for i=1:k
    tmp = zeros(n+k,n+k);
    tmp(n+i,n+i) = 1; 
    a_cone = [ a_cone -vec(tmp) ];
end
     
for i = 1:len
    tmp = zeros(n+k,n+k);
    tmp(1:n,1:n) = 1/lambda .* G{i};
    a_cone = [ a_cone  -vec(tmp) ];
    
end

At = [ At; a_cone ] ;
K.s = [ k + n ];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4. Set the objective function for the standard minimization problem;%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tmp = [ ];
tmp = [ ones(k,1); zeros(len,1) ];
b = -tmp;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5. Solve the SDP problem using SeDuMi Package;%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[x, y, info]=sedumi(At,b,C,K);
theta = y(k+1:end);
time = cputime - time0;
    
    


       
    
    




    








